create database designCilios;

use designCilios;

create table endereco(
	end_id int primary key auto_increment,
    end_cep varchar(9) not null,
    end_cidade varchar(30) not null,
    end_logradouro varchar(50),
    end_bairro varchar(30)
);

drop table cliente;

create table cliente(
cli_id int primary key auto_increment,
cli_nome varchar(8) not null,
cli_cpf char(11) not null unique,
cli_insta varchar (20),
cli_facebook varchar (30), 
cli_telefone char (11),
cli_complemento varchar(15),
cli_numero_cas varchar(6),
cli_data_cadastro date,
cli_endereco int,
foreign key (cli_endereco) references endereco(end_id)
on update cascade on delete cascade
);

select * from cliente;

create table calendario(
cal_id int primary key auto_increment,
cal_cli int,
foreign key(cal_cli) references cliente(cli_id)
on update cascade on delete cascade,
cal_dia date,
cal_hora time

);

create table espessura(
espe_id int primary key auto_increment,
espe_tam decimal (3,2) 
);
create table curvatura(
curv_id int primary key auto_increment,
curv_tam varchar (3)
);
create table tipo(
tipo_id int primary key auto_increment,
tipo_nome varchar (15)
);
create table modelo(
model_id int primary key auto_increment,
model_nome varchar (15)
);
create table tamanho(
tam_id int primary key auto_increment,
tam_cilios decimal (3,2)

);

-- Macro-regiões
create table macrorega(
mra_id int primary key auto_increment,
mra_tam int,
mra_esp int,
mra_cur int,
foreign key(mra_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mra_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mra_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

create table macroregb(
mrb_id int primary key auto_increment,
mrb_tam int,
mrb_esp int,
mrb_cur int,
foreign key(mrb_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mrb_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mrb_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

create table macroregc(
mrc_id int primary key auto_increment,
mrc_tam int,
mrc_esp int,
mrc_cur int,
foreign key(mrc_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mrc_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mrc_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

create table macroregd(
mrd_id int primary key auto_increment,
mrd_tam int,
mrd_esp int,
mrd_cur int,
foreign key(mrd_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mrd_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mrd_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

-- Micro-regiões
create table microrega(
mia_id int primary key auto_increment,
mia_tam int,
mia_esp int,
mia_cur int,
foreign key(mia_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mia_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mia_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

create table microregb(
mib_id int primary key auto_increment,
mib_tam int,
mib_esp int,
mib_cur int,
foreign key(mib_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mib_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mib_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

create table microregc(
mic_id int primary key auto_increment,
mic_tam int,
mic_esp int,
mic_cur int,
foreign key(mic_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mic_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mic_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

create table microregd(
mid_id int primary key auto_increment,
mid_tam int,
mid_esp int,
mid_cur int,
foreign key(mid_tam) references tamanho(tam_id)
on update cascade on delete cascade,
foreign key(mid_esp) references espessura(espe_id)
on update cascade on delete cascade,
foreign key(mid_cur) references curvatura(curv_id)
on update cascade on delete cascade
);

-- Design completo por cliente
create table design(
des_id int primary key auto_increment,
des_cli int,
des_tipo int,
des_model int,
des_macA int,
des_macB int,
des_macC int,
des_macD int,
des_micA int,
des_micB int,
des_micC int,
des_micD int,
des_anotacoes longtext,

-- Se deletar o design, deleta em cascata todas as informações associadas. 

foreign key(des_cli) references cliente(cli_id)
on update cascade on delete cascade,
foreign key(des_tipo) references tipo(tipo_id)
on update cascade on delete cascade,
foreign key(des_model) references modelo(model_id)
on update cascade on delete cascade,
foreign key(des_macA) references macrorega(mra_id)
on update cascade on delete cascade,
foreign key(des_macB) references macroregb(mrb_id)
on update cascade on delete cascade,
foreign key(des_macC) references macroregc(mrc_id)
on update cascade on delete cascade,
foreign key(des_macD) references macroregd(mrd_id)
on update cascade on delete cascade,
foreign key(des_micA) references microrega(mia_id)
on update cascade on delete cascade,
foreign key(des_micB) references microregb(mib_id)
on update cascade on delete cascade,
foreign key(des_micC) references microregc(mic_id)
on update cascade on delete cascade,
foreign key(des_micD) references microregd(mid_id)
on update cascade on delete cascade


);
-- Inserir tamanho (tam_cilios)
insert into tamanho(tam_cilios) values
('7'),
('8'),
('9'),
('10'),
('11'),
('12'),
('13'),
('14'),
('15'),
('16'),
('17'),
('18'),
('19'),
('20');


-- Inserir espessura (espe_tam)
insert into espessura (espe_tam) values
('0,10'),
('0,15'),
('0,20'),
('0,25'),
('0,30');

-- Inserir Curatura (cur_tam)
insert into curvatura (cur_tam) values
('C'),
('CC'),
('L'),
('M');

-- Inserir modelo (model_nome)
insert into modelo (model_nome) values
('Natural'),
('Raposa'),
('Gatinho'),
('Boneca'),
('Open Eye');

-- Inserir tipo (tipo_nome)
insert into tipo (tipo_nome) values
('Clássico'),
('Híbrido'),
('Volume Russo');

-- INSERIR 20 TUPLAS DE ENDEREÇO
insert into endereco(end_cep, end_cidade, end_logradouro, end_bairro) values
('13403-774','Piracicaba',' Rua 08 de Março','Ondas'),
('13428-403','Piracicaba',' Rua 10 de Agosto','Centro - Tupi'),
('13428-406','Piracicaba',' Rua 10 de Novembro','Centro - Tupi'),
('13428-415','Piracicaba',' Rua 16 de Julho','Centro - Tupi'),
('13412-332','Piracicaba',' Rua 86','Conjunto Residencial Mário Dedini'),
('13428-400','Piracicaba','Rua 9 de Julho','Centro - Tupi'),
('13425-686','Piracicaba',' Avenida A','Jardim Itamaracá'),
('13425-011','Piracicaba',' Rua A','Jardim Caxambu'),
('13432-018','Piracicaba',' Rua A','Centro - Ártemis'),
('13408-260','Piracicaba',' Rua A','Parque Orlanda III'),
('13420-628','Piracicaba',' Rua A','Jardim Flamboyant'),
('13401-411','Piracicaba',' Rua A','Jardim Tatuapé'),
('13423-213','Piracicaba',' Rua A','Santa Rita'),
('13423-200','Piracicaba',' Rua A','Santa Rita'),
('13423-216','Piracicaba',' Rua A','Santa Rita'),
('13401-582','Piracicaba',' Travessa A','Monte Líbano'),
('13401-566','Piracicaba',' Rua Abdo Maluf','Monte Líbano'),
('13403-016','Piracicaba',' Rua Abel Francisco Pereira','Jaraguá'),
('13413-071','Piracicaba',',Rua Abelardo Benedicto Libório - lado par,','Loteamento Distrito Industrial Uninorte),'),
('13413-075','Piracicaba',' Rua Abelardo Benedicto Libório - lado impar,','Loteamento Distrito Industrial Uninorte'),
('13400-780','Piracicaba',' Rua Luiz de Queiroz','Centro');


-- INSERIR 20 TUPLAS DE ENDEREÇO
insert into cliente(cli_nome, cli_cpf, cli_insta, cli_facebook, cli_telefone, cli_numero_cas, cli_complemento, cli_data_cadastro, cli_endereco) values
('Juliana Moura', '60000000000', 'aaaaa', 'fewhohfeug', '', '55', '', '2019-12-02', 12),
('Maria do Carmo', '50000000000', 'bbbbb', 'xxxxxx', '456', '', '', '2019-12-02', 2),
('Antoniete', '40000000000', '', '', '', '10560', '', '2019-12-02', 5),
('Julia', '03000000000', '', '', '', '', '356A', '2019-12-02', 7),
('Ana Brito', '12000000000', '', '', '', '99', '', '2019-12-02', 11),
('Dolores', '21000000000', '', '', '', '79', 'Ap 57', '2019-12-02', 12),
('Karla', '34010000000', '', '', '', '176', '', '2019-12-02', 15),
('Leticia', '00000022000', '', '', '', '', '', '2019-12-02', 1),
('Rubia', '00000006660', '', '', '', '', '', '2019-12-02', 3),
('Celeste', '00000009000', '', '', '', '', '', '2019-12-02', 4),
('Adriana', '00000777000', '', '', '', '', '', '2019-12-02', 9),
('Debora', '00000004400', '', '', '', '', '', '2019-12-02', 7),
('Juliana Santos', '23000000000', '', '', '', '', '', '2019-12-02', 16),
('Joana', '00000005000', '', '', '', '', '', '2019-12-02', 18),
('Cristina', '00019000000', '', '', '', '', '', '2019-12-02', 15),
('Fernanda', '00011000000', '', '', '', '', '', '2019-12-02', 11),
('Dayane', '00000010000', '', '', '', '', '', '2019-12-02', 10),
('Palloma', '00000001000', 'pallomatiba', 'pallomatiba', '19999999999', '2375', '', '2019-12-02', 13),
('Luana', '00000000011', '', '', '', '', '', '2019-12-02', 17),
('Beatriz', '00000000001', '', '', '', '', '', '2019-12-02', 11);

    

