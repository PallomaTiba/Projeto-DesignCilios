Projeto Design Cilios feito por Palloma Tiba e Jonathan Mendes

- Documenta��o do projeto na pasta "Engenharia de Software"
- O software est� na pasta "Codifica��o".
- Na pasta banco de dados est� o servidor local utilizado (Usbwebserver) e o script do banco para rodar. Para o servidor local rodar, basta executar o arquivo usbwebserver.exe que estar� funcionando normalmente ap�s isso.